import os
import joblib
import pandas as pd


_model = None

def load_model():
    global _model
    if _model is None:
        _model = joblib.load(os.path.join(BASE_DIR, 'models', os.listdir(os.path.join(BASE_DIR, 'models'))[0]))
    return _model


BASE_DIR = os.path.dirname(os.path.abspath(__file__))



features = [
    'Income', 'Disposable_Income', 'Essential_Expenses',
    'Non_Essential_Expenses', 'Total_Expenses_to_Income_Ratio',
    'Desired_Savings_Percentage', 'Savings_Efficiency', 'Debt_to_Income_Ratio'
]

def predict_financial_health_score(input_data: dict):
    input_df = pd.DataFrame([input_data])
    score = model.predict(input_df[features])[0]
    return round(score, 2)
