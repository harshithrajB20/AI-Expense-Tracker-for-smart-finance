import os
import joblib
import pandas as pd


_model = None

def load_model():
    global _model
    if _model is None:
        _model = joblib.load(os.path.join(BASE_DIR, 'models', os.listdir(os.path.join(BASE_DIR, 'models'))[0]))
    return _model


# Get the absolute path to this file's directory
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Load the trained XGBoost model


# Features used by the model
alert_features = [
    'Income', 'Total_Expenses', 'Rent_to_Income_Ratio',
    'Groceries_to_Income_Ratio', 'Total_Expenses_to_Income_Ratio',
    'Savings_Efficiency', 'Essential_Expenses', 'Non_Essential_Expenses'
]

def predict_overspending_alert(input_data: dict) -> bool:
    """
    Predict whether the user is overspending.
    """
    input_df = pd.DataFrame([input_data])
    prediction = overspending_model.predict(input_df[alert_features])
    return bool(prediction[0])
